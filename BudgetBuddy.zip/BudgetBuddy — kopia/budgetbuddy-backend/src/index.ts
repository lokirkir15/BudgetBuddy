import express from "express";
import dotenv from "dotenv";
import authRoutes from "./routes/authRoutes";
import transactionRoutes from "./routes/transactionRoutes";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use("/auth", authRoutes);
app.use(express.json());
app.use("/transactions", transactionRoutes);

app.get("/", (req, res) => {
  res.send("BudgetBuddy API działa! 🚀");
});

app.listen(PORT, () => {
  console.log(`Serwer działa na porcie ${PORT}`);
});
