import { Request, Response } from "express";
import prisma from "../config/prisma";

export const createTransaction = async (
  req: Request,
  res: Response
): Promise<void> => {
  const { type, amount, category, date, note } = req.body;
  const user = (req as any).user;

  if (!type || !amount || !category || !date) {
    res.status(400).json({ message: "Wszystkie wymagane pola muszą być uzupełnione." });
    return;
  }

  try {
    const transaction = await prisma.transaction.create({
      data: {
        type,
        amount,
        category,
        date: new Date(date),
        note,
        userId: user.id,
      },
    });

    res.status(201).json(transaction);
  } catch (error) {
    res.status(500).json({ message: "Błąd podczas tworzenia transakcji." });
  }
};

export const getTransactions = async (
  req: Request,
  res: Response
): Promise<void> => {
  const user = (req as any).user;

  try {
    const transactions = await prisma.transaction.findMany({
      where: { userId: user.id },
      orderBy: { date: "desc" },
    });

    res.status(200).json(transactions);
  } catch (error) {
    res.status(500).json({ message: "Błąd przy pobieraniu transakcji." });
  }
};

export const updateTransaction = async (
  req: Request,
  res: Response
): Promise<void> => {
  const user = (req as any).user;
  const { id } = req.params;
  const { type, amount, category, date, note } = req.body;

  try {
    const existing = await prisma.transaction.findUnique({
      where: { id: parseInt(id) },
    });

    if (!existing || existing.userId !== user.id) {
      res.status(403).json({ message: "Brak dostępu lub transakcja nie istnieje." });
      return;
    }

    const updated = await prisma.transaction.update({
      where: { id: parseInt(id) },
      data: {
        type,
        amount,
        category,
        date: new Date(date),
        note,
      },
    });

    res.status(200).json(updated);
  } catch (error) {
    res.status(500).json({ message: "Błąd przy edytowaniu transakcji." });
  }
};

export const deleteTransaction = async (
  req: Request,
  res: Response
): Promise<void> => {
  const user = (req as any).user;
  const { id } = req.params;

  try {
    const existing = await prisma.transaction.findUnique({
      where: { id: parseInt(id) },
    });

    if (!existing || existing.userId !== user.id) {
      res.status(403).json({ message: "Brak dostępu lub transakcja nie istnieje." });
      return;
    }

    await prisma.transaction.delete({
      where: { id: parseInt(id) },
    });

    res.status(200).json({ message: "Transakcja usunięta." });
  } catch (error) {
    res.status(500).json({ message: "Błąd przy usuwaniu transakcji." });
  }
};
